# -*- coding: utf-8 -*-

from . import administrative_communications
from . import res_users
